import Navbar from "../../components/ui/Navbar"
import Herohome from "../auth/Herohome"
import Login from "../auth/Login"
import Footer from "../../components/ui/Footer"
import Courses from "../auth/Courses"
import Sidebar from "../admin/Sidebar"


function Homepage() {
  return (
    <div>
      {/* <Navbar/> */}
      <Herohome/>
      {/* <Courses/> */}
      
      
       {/* <Footer />      */}
       
    </div>
  )
}

export default Homepage
