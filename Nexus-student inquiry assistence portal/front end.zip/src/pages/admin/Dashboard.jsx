import React, { useState } from "react";

const AdminDashboard = () => {
  const [courses, setCourses] = useState([
    { id: 1, name: "Course 1" },
    { id: 2, name: "Course 2" },
    // Add more courses as needed
  ]);

  const [users, setUsers] = useState([
    { id: 1, name: "User 1" },
    { id: 2, name: "User 2" },
    // Add more users as needed
  ]);

  const [showAddCourseModal, setShowAddCourseModal] = useState(false);
  const [newCourseName, setNewCourseName] = useState("");

  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [newUserName, setNewUserName] = useState("");

  const handleAddCourse = () => {
    const newCourse = { id: courses.length + 1, name: newCourseName };
    setCourses([...courses, newCourse]);
    setShowAddCourseModal(false);
    setNewCourseName("");
  };

  const handleDeleteCourse = (id) => {
    const updatedCourses = courses.filter((course) => course.id !== id);
    setCourses(updatedCourses);
  };

  const handleAddUser = () => {
    const newUser = { id: users.length + 1, name: newUserName };
    setUsers([...users, newUser]);
    setShowAddUserModal(false);
    setNewUserName("");
  };

  const handleDeleteUser = (id) => {
    const updatedUsers = users.filter((user) => user.id !== id);
    setUsers(updatedUsers);
  };

  return (
    <div className="p-8 bg-gray-100">
      <h1 className="text-2xl font-semibold mb-4">Admin Dashboard</h1>

      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-2">Courses</h2>
        <button className="bg-blue-500 text-white px-4 py-2 mb-4" onClick={() => setShowAddCourseModal(true)}>
          Add Course
        </button>
        <table className="w-full border">
          <thead>
            <tr>
              <th className="border">ID</th>
              <th className="border">Name</th>
              <th className="border">Actions</th>
            </tr>
          </thead>
          <tbody>
            {courses.map((course) => (
              <tr key={course.id}>
                <td className="border">{course.id}</td>
                <td className="border">{course.name}</td>
                <td className="border">
                  <button
                    className="bg-red-500 text-white px-2 py-1"
                    onClick={() => handleDeleteCourse(course.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-2">Users</h2>
        <button className="bg-green-500 text-white px-4 py-2 mb-4" onClick={() => setShowAddUserModal(true)}>
          Add User
        </button>
        <table className="w-full border">
          <thead>
            <tr>
              <th className="border">ID</th>
              <th className="border">Name</th>
              <th className="border">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id}>
                <td className="border">{user.id}</td>
                <td className="border">{user.name}</td>
                <td className="border">
                  <button
                    className="bg-red-500 text-white px-2 py-1"
                    onClick={() => handleDeleteUser(user.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add Course Modal */}
      {showAddCourseModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50">
          <div className="bg-white p-8 w-96">
            <h2 className="text-lg font-semibold mb-4">Add Course</h2>
            <input
              type="text"
              value={newCourseName}
              onChange={(e) => setNewCourseName(e.target.value)}
              placeholder="Course Name"
              className="border p-2 w-full mb-4"
            />
            <div className="flex justify-end">
              <button className="bg-blue-500 text-white px-4 py-2" onClick={handleAddCourse}>
                Add
              </button>
              <button className="ml-4 text-gray-500" onClick={() => setShowAddCourseModal(false)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add User Modal */}
      {showAddUserModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50">
          <div className="bg- p-8 w-96">
            <h2 className="text-lg font-semibold mb-4">Add User</h2>
            <input
              type="text"
              value={newUserName}
              onChange={(e) => setNewUserName(e.target.value)}
              placeholder="User Name"
              className="border p-2 w-full mb-4"
            />
            <div className="flex justify-end">
              <button className="bg-green-500 text-white px-4 py-2" onClick={handleAddUser}>
                Add
              </button>
              <button className="ml-4 text-gray-500" onClick={() => setShowAddUserModal(false)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
