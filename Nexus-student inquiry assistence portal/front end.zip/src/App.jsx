import { Navigate, Route, Routes } from "react-router-dom"
import { lazy } from "react"
import LazyLayout from "./components/ui/LazyLayout"
import UserLayout from "./pages/user/UserLayout"
import { Sidebar } from "./pages/admin/Sidebar"
const LazyLogin = lazy(() => import("./pages/auth/Login"))
const LazyReg = lazy(() => import("./pages/auth/Signup"))
const LazyHome = lazy(() => import("./pages/user/Homepage"))
const LazyAbout = lazy(() => import("./pages/auth/About"))
const LazyAccount = lazy(() => import("./pages/user/Account"))
const LazyCourses = lazy(() => import("./pages/auth/Courses"))
const LazyContact = lazy(() => import("./pages/auth/Contact"))
const LazySidebar = lazy(() => import("./pages/admin/Sidebar"))
const LazyDashboard = lazy(() => import("./pages/admin/Dashboard"))
 



const UserRoutes = () => {
  return (
    <UserLayout>
      <Routes>
        <Route path="/home" element={<LazyLayout component={LazyHome} />} />
        <Route path="/account" element={<LazyLayout component={LazyAccount} />} />
        <Route path="/sidebar" element={<LazyLayout component={LazySidebar} />} />
        <Route path="/dashboard" element={<LazyLayout component={LazyDashboard} />} />

        {/* <Route path="/shop" element={<LazyLayout component={Lazyshop} />} />
        <Route path="/profile" element={<LazyLayout component={Lazyprofile} />} /> */}
      </Routes>
    </UserLayout>
  )
}
function App() {
  return (
    <div>
      
      <Routes>
        <Route exact path="/" element={<Navigate to="/demo-project/user/home" />} />
        <Route path="/demo-project/login" element={<LazyLayout component={LazyLogin} />} />
        <Route path="/demo-project/signup" element={<LazyLayout component={LazyReg} />} />
        <Route path="/demo-project/account" element={<LazyLayout component={LazyAccount} />} />
        <Route path="/demo-project/about" element={<LazyLayout component={LazyAbout} />} />
        <Route path="/demo-project/courses" element={<LazyLayout component={LazyCourses} />} />
        <Route path="/demo-project/contact" element={<LazyLayout component={LazyContact} />} />
        <Route path="/demo-project/sidebar" element={<LazyLayout component={LazySidebar} />} />
        <Route path="/demo-project/dashboard" element={<LazyLayout component={LazyDashboard} />} />


        <Route path="/demo-project/user/*" element={<UserRoutes />} />
        {/* <Route path='/sidebar' element={<Sidebar/>}/> */}
      </Routes>

    </div>
  )
}

export default App