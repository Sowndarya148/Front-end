import {
    Card,
    Typography,
    List,
    ListItem,
    ListItemPrefix,
    ListItemSuffix,
    Chip,
  } from "@material-tailwind/react";
  import {
    PresentationChartBarIcon,
    ShoppingBagIcon,
    UserCircleIcon,
    Cog6ToothIcon,
    InboxIcon,
    PowerIcon,
  } from "@heroicons/react/24/solid";
  import { BrowserRouter as Router, Route, Link } from "react-router-dom";


   
  export function Sidebar() {
    return (
      <Card className="h-[calc(100vh-2rem)] w-full max-w-[20rem] p-4 shadow-xl shadow-blue-gray-900/5 bg-purple-900">
  <div className="mb-2 p-4 border-b border-blue-900">
    <Typography variant="h5" color="white">


          
            Sidebar
          </Typography>
        </div>
        <List>
          <ListItem>
            <ListItemPrefix>
              <PresentationChartBarIcon className="h-5 w-5 text-white"/>
            </ListItemPrefix>
            <Link to="/demo-project/dashboard" className="text-white">
            Dashboard
            </Link>
          </ListItem>
          {/* <ListItem>
            <ListItemPrefix>
              <ShoppingBagIcon className="h-5 w-5"  />
            </ListItemPrefix>
            E-Commerce
          </ListItem> */}
          {/* <ListItem>
            <ListItemPrefix>
              <InboxIcon className="h-5 w-5" />
            </ListItemPrefix>
            Inbox
            <ListItemSuffix>
              <Chip value="14" size="sm" variant="ghost" color="blue-gray" className="rounded-full" />
            </ListItemSuffix>
          </ListItem> */}
          <ListItem>
            <ListItemPrefix>
              <UserCircleIcon className="h-5 w-5 text-white" />
            </ListItemPrefix>
            <Link to="/demo-project/account" className="text-white">
            Profile
            </Link>
          </ListItem>
          {/* {/* <ListItem>
            <ListItemPrefix>
              <Cog6ToothIcon className="h-5 w-5" />
            </ListItemPrefix>
            Settings
          </ListItem> */}
          <ListItem> 
            <ListItemPrefix>
              <PowerIcon className="h-5 w-5 text-white" />
            </ListItemPrefix>
            <Link to="/demo-project/login" className="text-white">
            Log Out
            </Link>
          </ListItem>
        </List>
      </Card>
    );
  }
  export default Sidebar;